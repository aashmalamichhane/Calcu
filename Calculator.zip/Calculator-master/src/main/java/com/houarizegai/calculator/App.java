package com.houarizegai.calculator;

import com.houarizegai.calculator.ui.CalculatorUI;

public class App {

    public static void main(String[] args) {
        new CalculatorUI();
    }
}
